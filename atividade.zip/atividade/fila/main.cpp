#include <iostream>
#include <queue>
#include <stack>
#include <string>

using namespace std;

// Cabe�alho do programa
// Nome do aluno: [Seu Nome]
// Objetivo do programa: Armazenar matr�culas e notas em uma fila e orden�-las em uma pilha com a maior nota no topo.
// Entrada de dados: Matr�culas e notas fornecidas pelo usu�rio.
// Resultado da execu��o: Exibi��o das matr�culas e notas ordenadas.

struct Aluno {
    string matricula; // Matr�cula do aluno
    float nota;       // Nota do aluno
};

// Fun��o para comparar duas notas
bool comparaNotas(const Aluno &a, const Aluno &b) {
    if (a.nota == b.nota) {
        return a.matricula < b.matricula; // Empate de notas � resolvido pela matr�cula
    }
    return a.nota > b.nota; // Nota maior deve vir primeiro
}

int main() {
    queue<Aluno> fila; // Fila para armazenar matr�culas e notas
    stack<Aluno> pilha; // Pilha para armazenar os alunos ordenados

    // Entrada de dados
    string matricula;
    float nota;
    char continuar;

    do {
        Aluno aluno;
        cout << "Digite a matricula do aluno: ";
        cin >> aluno.matricula;
        cout << "Digite a nota do aluno: ";
        cin >> aluno.nota;

        fila.push(aluno); // Armazena na fila

        cout << "Deseja adicionar outro aluno? (s/n): ";
        cin >> continuar;

    } while (continuar == 's' || continuar == 'S');


    while (!fila.empty()) {
        Aluno aluno = fila.front();
        fila.pop();


        stack<Aluno> tempStack;
        while (!pilha.empty() && comparaNotas(pilha.top(), aluno)) {
            tempStack.push(pilha.top());
            pilha.pop();
        }
        pilha.push(aluno);
        while (!tempStack.empty()) {
            pilha.push(tempStack.top());
            tempStack.pop();
        }
    }

    // Exibindo resultados
    cout << "\nAlunos em ordem decrescente de notas:\n";
    while (!pilha.empty()) {
        Aluno aluno = pilha.top();
        pilha.pop();
        cout << "Matricula: " << aluno.matricula << ", Nota: " << aluno.nota << endl;
    }

    return 0;
}
